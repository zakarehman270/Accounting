declare module "react-avatar-editor";
