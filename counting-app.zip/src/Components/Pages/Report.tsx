import React from "react";
import Header from "../Header/Header";

const Report = () => {
	return (
		<div>
			<Header />
			<h1 className="mt-5 text-center TextHolderPagesHeading">Report</h1>
		</div>
	);
};

export default Report;
