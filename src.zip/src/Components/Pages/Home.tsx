import React from "react";
import Header from "../Header/Header";

const Home = () => {
	return (
		<div>
			<Header />
			<h1 className="mt-5 text-center TextHolderPagesHeading">Home</h1>
		</div>
	);
};
export default Home;
