export enum ModalEnumData {
	ModalAddUser = "ModalAddUser",
	ModalEditUser = "ModalEditUser",
	ModalAlert = "ModalAlert",
	ModalAddLoan = "ModalAddLoan",
	ModalUploadPhoto = "ModalUploadPhoto",
}
